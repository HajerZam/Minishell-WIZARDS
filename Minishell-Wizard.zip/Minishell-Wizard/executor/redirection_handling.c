/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirection_handling.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: halzamma <halzamma@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/08 19:45:45 by halzamma          #+#    #+#             */
/*   Updated: 2025/09/06 22:02:16 by halzamma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int	setup_redirections(t_cmd *cmd)
{
	if (!cmd)
		return (1);
	if (cmd->input_fd != 0)
	{
		if (dup2(cmd->input_fd, STDIN_FILENO) == -1)
		{
			perror("dup2");
			return (1);
		}
		if (cmd->input_fd > 2)
			close(cmd->input_fd);
	}
	if (cmd->output_fd != 1)
	{
		if (dup2(cmd->output_fd, STDOUT_FILENO) == -1)
		{
			perror("dup2");
			return (1);
		}
		if (cmd->output_fd > 2)
			close(cmd->output_fd);
	}
	return (0);
}

int	backup_std_fds(t_exec_context *ctx)
{
	ctx->stdin_backup = dup(STDIN_FILENO);
	ctx->stdout_backup = dup(STDOUT_FILENO);
	if (ctx->stdin_backup == -1 || ctx->stdout_backup == -1)
	{
		perror("dup");
		return (1);
	}
	return (0);
}

static int	restore_stdin(t_exec_context *ctx)
{
	if (ctx->stdin_backup != -1)
	{
		if (dup2(ctx->stdin_backup, STDIN_FILENO) == -1)
		{
			perror("dup2");
			return (1);
		}
		close(ctx->stdin_backup);
		ctx->stdin_backup = -1;
	}
	return (0);
}

static int	restore_stdout(t_exec_context *ctx)
{
	if (ctx->stdout_backup != -1)
	{
		if (dup2(ctx->stdout_backup, STDOUT_FILENO) == -1)
		{
			perror("dup2");
			return (1);
		}
		close(ctx->stdout_backup);
		ctx->stdout_backup = -1;
	}
	return (0);
}

int	restore_std_fds(t_exec_context *ctx)
{
	int	result;

	result = 0;
	if (restore_stdin(ctx) != 0)
		result = 1;
	if (restore_stdout(ctx) != 0)
		result = 1;
	return (result);
}
