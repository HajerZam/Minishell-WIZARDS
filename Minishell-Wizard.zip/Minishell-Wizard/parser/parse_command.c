/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_command.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: halzamma <halzamma@student.42roma.it>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/07 14:59:45 by halzamma          #+#    #+#             */
/*   Updated: 2025/08/29 12:49:17 by halzamma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

static void	cleanup_argv_on_error(char **argv, int allocated_count)
{
	int	i;

	i = 0;
	if (!argv)
		return ;
	while (i < allocated_count && argv[i])
	{
		free(argv[i]);
		i++;
	}
	free(argv);
}

int	pce_error_check(t_parser *parser, t_cmd *cmd, int arg_count, int arg_index)
{
	while (parser->current && parser->current->type != PIPE)
	{
		if (parser->current->type == WORD)
		{
			if (handle_word_token(cmd, parser, &arg_index, arg_count) == 0)
				return (0);
		}
		else if (is_redirection(parser->current->type))
		{
			if (parse_redirections(parser, cmd) == 0)
				return (0);
		}
		else
		{
			ft_putstr_fd("wizardshell: syntax error!\n", 2);
			parser->error = 1;
			return (0);
		}
	}
	return (1);
}

int	parse_command_elements(t_parser *parser, t_cmd *cmd)
{
	int	arg_count;
	int	arg_index;

	arg_count = count_words_until_pipe(parser);
	if (arg_count > 0)
	{
		cmd->argv = allocate_argv(arg_count);
		if (!cmd->argv)
		{
			parser->error = 1;
			return (0);
		}
	}
	arg_index = 0;
	if (pce_error_check(parser, cmd, arg_count, arg_index) == 0)
	{
		if (cmd->argv)
		{
			cleanup_argv_on_error(cmd->argv, arg_count);
			cmd->argv = NULL;
		}
		return (0);
	}
	return (1);
}

t_cmd	*create_cmd(void)
{
	t_cmd	*cmd;

	cmd = (t_cmd *)malloc(sizeof(t_cmd));
	if (!cmd)
	{
		perror("Failed to allocate memory for command");
		return (NULL);
	}
	cmd->argv = NULL;
	cmd->input_fd = 0;
	cmd->output_fd = 1;
	cmd->next = NULL;
	cmd->tokens = NULL;
	cmd->heredoc_fd = -1;
	cmd->is_heredoc = 0;
	cmd->is_builtin = 0;
	cmd->envp = NULL;
	cmd->exit_status = 0;
	return (cmd);
}

t_cmd	*parse_command(t_parser *parser)
{
	t_cmd	*cmd;

	if (!parser->current)
		return (NULL);
	cmd = create_cmd();
	if (!cmd)
	{
		parser->error = 1;
		return (NULL);
	}
	if (!parse_command_elements(parser, cmd))
	{
		free_cmd(cmd);
		return (NULL);
	}
	if (!validate_parsed_command(cmd, parser))
	{
		free_cmd(cmd);
		return (NULL);
	}
	finalize_command(cmd);
	return (cmd);
}
