/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: halzamma <halzamma@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/13 12:06:59 by fepennar          #+#    #+#             */
/*   Updated: 2025/09/10 13:45:35 by halzamma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minishell.h"

char	*extract_var_name(const char *str)
{
	char	*eq_position;
	char	*append_position;
	int		key_len;

	append_position = ft_strstr(str, "+=");
	eq_position = ft_strchr(str, '=');
	if (append_position && (!eq_position || append_position < eq_position))
	{
		key_len = append_position - str;
		return (ft_substr(str, 0, key_len));
	}
	if (!eq_position)
		return (ft_strdup(str));
	key_len = eq_position - str;
	return (ft_substr(str, 0, key_len));
}

char	*extract_var_value(const char *str)
{
	char	*eq_position;
	char	*append_position;

	append_position = ft_strstr(str, "+=");
	eq_position = ft_strchr(str, '=');
	if (append_position && (!eq_position || append_position < eq_position))
		return (ft_strdup(append_position + 2));
	if (!eq_position)
		return (NULL);
	return (ft_strdup(eq_position + 1));
}

/* Searches for a specific variable in the env list */
t_env	*find_env_var(t_env *env, const char *key)
{
	t_env	*current;

	current = env;
	while (current)
	{
		if (ft_strcmp(current->key, key) == 0)
			return (current);
		current = current->next;
	}
	return (NULL);
}

/* Creates a new variable and allocates memory for the node key and value
   and adds the node on top of the list*/
int	add_env_var_exported(t_env **env, const char *key, const char *value)
{
	t_env	*new_node;

	new_node = malloc(sizeof(t_env));
	if (!new_node)
		return (0);
	new_node->key = ft_strdup(key);
	if (value)
		new_node->value = ft_strdup(value);
	else
		new_node->value = NULL;
	new_node->is_exported = 1;
	if (!new_node->key || (value && !new_node->value))
	{
		free(new_node->key);
		free(new_node->value);
		free(new_node);
		return (0);
	}
	new_node->next = *env;
	*env = new_node;
	return (1);
}

/* Export a variable with assignment (VAR=value)
 if it exists it updates the value and the flag, if not
 It creates a New Exported Variable */
int	export_with_assignment(const char *key, const char *value, t_env **env)
{
	t_env	*existing;
	char	*new_value;

	existing = find_env_var(*env, key);
	if (existing)
	{
		if (value)
		{
			new_value = ft_strdup(value);
			if (!new_value)
				return (0);
		}
		else
			new_value = NULL;
		free(existing->value);
		existing->value = new_value;
		existing->is_exported = 1;
		return (1);
	}
	return (add_env_var_exported(env, key, value));
}
